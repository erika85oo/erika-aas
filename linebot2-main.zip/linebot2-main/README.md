# linebot2
DynamoDBを使ったLINE Botの本格的なコードにしたいやつ
